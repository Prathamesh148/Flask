from flask import *
import numpy as np
import pandas as pd
import warnings                                  
warnings.filterwarnings('ignore')
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')
#-----------------------------------------------------------------------
app = Flask(__name__,template_folder="template")
#----------------------------------------------------------------------- 
@app.route('/')  
def hello():
      return render_template('pk.html')
#----------------------------------------------------------------------- 
@app.route('/sb', methods=['POST'])  
def submit():
      
      if request.method=="POST":
            sentence=request.form["sentence"]
            sid = SentimentIntensityAnalyzer()
            a=sid.polarity_scores(sentence)
            b=a['neg']
            c=a['neu']
            d=a['pos']
            if b>0.5:
                  e="Negative"
                  return render_template('sb.html',n=e)
            elif c>0.5:
                  e="Neutral"
                  return render_template('sb.html',n=e)
            elif d>0.5:
                  e="Positive"
                  return render_template('sb.html',n=e)
                  
      #return render_template('sb.html',n=a)
#-------------------------------------------------------------------------
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
#-------------------------------------------------------------------------
