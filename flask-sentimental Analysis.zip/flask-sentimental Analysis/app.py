from flask import *
print(4)
import numpy as np
print(3)
import pandas as pd
print(2)
import warnings                                  
warnings.filterwarnings('ignore')
print(1)
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
nltk.download('vader_lexicon')
#-----------------------------------------------------------------------
app = Flask("PRATHAMESH",template_folder="template")#__name__,template_folder="template"
#----------------------------------------------------------------------- 
@app.route('/')  
def hello():
      return render_template('pk.html')
#----------------------------------------------------------------------- 
@app.route('/sb', methods=['POST'])  
def review():
      
      if request.method=="POST":
            sentence=request.form["sentence"]
            sid = SentimentIntensityAnalyzer()
            a=sid.polarity_scores(sentence)
            b=a['neg']
            c=a['neu']
            d=a['pos']
            if b>0.5:
                  e="Negative"
                  n=e
                  return render_template('sb.html',n=e)
            elif c>0.5:
                  e="Neutral"
                  return render_template('sb.html',n=e)
            elif d>0.5:
                  e="Positive"
                  return render_template('sb.html',n=e)
#-------------------------------------------------------------------------
if __name__ == '__main__':
      app.run()
    #app.run(debug=True)
#-------------------------------------------------------------------------
print("http://localhost:5000/")
